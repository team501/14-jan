import React, { Component } from 'react';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import './land.css'; 
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css';
import {Link} from 'react-router-dom';


class ChuteStatusInfo extends Component {
  constructor(props) {
    super(props);

    this.options = {
      sortIndicator: false  // disable sort indicator
    };
  }
 
  
  render() {
    return (
 
   
     <div>
     <div className='chuteHeader1' >Unit Sorter Dashboard >> {this.props.lastLink} >> <span className="chute-text-bold">Chute Status</span></div>
     <div className="chuteHeader2">
       <Link to={{ pathname: '/sorterdetails', state: { data: this.props.lastLink } }}>
       <span className="glyphicon glyphicon-arrow-left"></span></Link> Chute Status </div>
     <div className="tableDiv">
      <BootstrapTable data={ this.props.data } options={ this.options } bordered={ false } className="chuteTable"
        >
        <TableHeaderColumn dataField='chute_nbr' isKey className="cheader" dataSort>Chute No. </TableHeaderColumn>
        <TableHeaderColumn dataField='product_full' className="cheader">Full</TableHeaderColumn>
        <TableHeaderColumn dataField='product_disabled' className="cheader">Disabled</TableHeaderColumn>
        <TableHeaderColumn dataField='duration' className="cheader" dataSort>Duration</TableHeaderColumn>
        <TableHeaderColumn dataField='created_ts' className="cheader" dataSort>Timestamp</TableHeaderColumn>
      </BootstrapTable>
      </div>
      </div>
    );
  }
}

export default ChuteStatusInfo;
