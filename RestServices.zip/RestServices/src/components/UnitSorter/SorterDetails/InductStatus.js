import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import {Link} from 'react-router-dom';
import BarChart from '../../Chart2js/BarChart';
import {baseURL} from '../../../Config.js';
import axios from 'axios';
import '../land.css';

const headingGrid = {
		
};

const headingGrid2 = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'medium',
		padding: '5px'
};

const headingGrid3 = {
		height: '25px',
	    fontSize: 'medium',
		padding: '5px'
};

const bottomGrid = {
		textAlign: 'left',
		height: '25px',
	    fontSize: 'x-large',
		padding: '5px'
};

const mainGrid = {
		padding: '25px',
		height: '170px',
};

const gridContent = {
		height: '70px',
		padding: '20px',
		fontSize: 'xx-large'	
};

class index extends Component {
	
	constructor(props) {
		super(props);
		this.state = {  label: [],
						graphData: [],
					    isLoading:true
					  };
	}
	
	async componentWillMount() {
		axios.get(baseURL+'inductionstatusperhour/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    let label = new Array();
			    label.push("Peak");
			    label.push("Average");
			    label.push("Recric");
			    label.push("Minimum");
			    
			    let graphData = new Array();
			    graphData.push(res.data.peak);
			    graphData.push(res.data.average);
			    graphData.push(res.data.recric);
			    graphData.push(res.data.minimum);
			    
			    console.log("INDSPHR");
			    console.log(graphData);
			    console.log(label);
		        this.setState({ label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}
	
	render() { 
		if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else { return (
			
					<Grid container>
						<Grid className="all-header-grid" item xs={12} sm={12}>
							<strong>Induction status per hour</strong>
						</Grid>
						<Grid style={mainGrid} container spacing={24}>
							<Grid item xs={8} sm={8}>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									<BarChart label={this.state.label} graphData={this.state.graphData} />
								</Grid>
							</Grid>
							
							<Grid item xs={4} sm={4}>
								<Grid style={headingGrid2} item xs={12} sm={12}>
									
									<div className="right-arrow1"> 
									
										<Link to={{ pathname: '/inductStatus', state: { nextLink: this.props.nextLink } }}> <span className="glyphicon glyphicon-menu-right"></span> </Link>
										</div>
								</Grid>
							</Grid>
						</Grid>	
					</Grid>	);
				}
		}
}
export default index;