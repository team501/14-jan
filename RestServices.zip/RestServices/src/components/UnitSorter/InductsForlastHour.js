import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';
import LineChart from '../Chart2js/lineChart';
import SpeedoMeter from '../Chart2js/SpeedoMeter';
import {baseURL} from '../../Config.js';
import axios from 'axios';
import NumberClass from './NumberClass';

const headingGrid = {
		
};

const mainGrid = {
		padding: '0px',
		height: '0px',
};

const leftcontentDiv = {
		padding: '2px',
		height: '100%'
};

const rightcontentDiv = {
		height: '70px',
		marginRight:'20px'
};

const footGrid = {
		height: '100px',
		marginTop:'20'
};
const footlevel = {
		marginLeft:'7%',
		marginRight:'7%',
		position:'absolute',
		marginTop:'0%'
		
};

class index extends Component{
	constructor(props) {
		super(props);
		this.state = {  data: {},
						label: [],
						graphData: [],
					    isLoading:true
					  };
	}
	
	async componentWillMount() {
		axios.get(baseURL+'inductsforlasthour/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    console.log(res.data);
			    let label = res.data.inductsForLastHour.map(list => list.currentHour);
			    let graphData = res.data.inductsForLastHour.map(list => list.currValue);
			    
			    console.log(graphData);
		        this.setState({ data: res.data,
		        				label: label,
		        				graphData: graphData,
					        	isLoading:false}); })
			.catch(function (error) {
				console.log(error);
		  });
	}
	
	render(){
		
		if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else {
			return (
					<Grid container spacing={2}>
						<Grid className="all-header-grid" item xs={12} sm={12}>
							<strong>Inducts for Last hour</strong>
						</Grid>
						<Grid xs={12} sm={4}>
							<div style={leftcontentDiv}>
								<div style={{padding: '20px 0px 0px 0px'}}>
									<SpeedoMeter value={this.state.data.percentValue}/>
									<div style={{fontSize: 'x-large', textAlign:'center', paddingLeft: '25px'}}>{this.state.data.percentValue}%</div>
								</div>
							</div>
						</Grid>
						<Grid style={mainGrid} item xs={12} sm={8} container>
							<Grid item xs={12} sm={12}>
								<div style={rightcontentDiv}>
									<Grid container className="kpi-text-heading">
										<Grid item xs={12} sm={12}><span className="kpi-value-left"><NumberClass number={this.state.data.currentValue} /></span> /
										<label className="kpi-value-right">&nbsp;<NumberClass number={this.state.data.goalValue} /></label></Grid>
									</Grid>
								</div>
							</Grid>
							<Grid style={footGrid} item xs={12} sm={12}>
							<div style={footlevel}>Last 5 Days</div>
								<div className="lineChart" style={footGrid}>
									<LineChart  label={this.state.label} graphData={this.state.graphData} color={'orange'}/>
								</div>
							</Grid>
						</Grid>
					</Grid>	);
			}
	}
}
export default index;
